// using System;

// namespace Curs2 
// {
//     public class WhileExample 
//     {
//         public static void Main()
//         {
//             int number = Convert.ToInt32(Console.ReadLine());
//             Console.Write("\n\n\n");

//             while(number > 0)
//             {
//                 Console.Write(number + "\t");
//                 number --;
//             }
//         }
//     }
// }