using System;

namespace Curs2 
{
    public class ConvertExample 
    {
        public static void Main()
        {
            int a = (int) 4.66;
            Console.WriteLine(a);
        }
    }
}