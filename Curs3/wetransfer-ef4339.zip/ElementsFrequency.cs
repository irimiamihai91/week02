﻿using System;
using System.Collections.Generic;

namespace Homework2_ElemFreq
{
    class MainClass
    {
        public static Dictionary<int, int> ElemFreq(int[] array)
        {
            Dictionary<int, int> dict = new Dictionary<int, int>();

            for (int i = 0; i < array.Length; i++)
            {
                if (!dict.ContainsKey(array[i]))
                    dict[array[i]] = 1;
                else
                    dict[array[i]] += 1;
            }

            return dict;
        }




        public static void Main(string[] args)
        {
            Random rand = new Random();
            int[] a = new int[rand.Next(10, 20)];

            for (int i = 0; i < a.Length; i++)
            {
                a[i] = rand.Next(0, 10);
                Console.Write(a[i] + " ");
            }
            Console.WriteLine(Environment.NewLine);


            Dictionary<int, int> result = ElemFreq(a);
        
            foreach (var keyVal in result)
                Console.WriteLine(keyVal);
        }
    }
}
